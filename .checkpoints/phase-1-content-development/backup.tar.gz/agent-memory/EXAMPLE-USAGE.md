# Agent Memory System - Example Usage

## Scenario: Starting a New Session

### Step 1: Check Previous Work

When you return to this project, first check what was done before:

```bash
# View statistics
node .agent-memory/utils.js stats

# Output:
# {
#   "totalSessions": 1,
#   "totalModifications": 6,
#   "lastSessionDate": "2025-10-13T00:25:44.265Z",
#   "currentSession": null,
#   "recentFiles": [...]
# }
```

### Step 2: Review Last Session

```bash
# See recent sessions
node .agent-memory/utils.js recent-sessions 3

# Read the last session log
cat .agent-memory/logs/session-1760315098769.md
```

### Step 3: Start Working

As soon as you log your first action, a new session is automatically created:

```bash
# This creates a new session automatically
node .agent-memory/utils.js log-interaction \
  "Please add a new feature to the homepage" \
  "Creating new homepage feature component"
```

### Step 4: Log Your Work

```bash
# When you create a file
node .agent-memory/utils.js log-file \
  "app/components/Feature.tsx" \
  "create" \
  "Created new feature component for homepage"

# When you edit a file
node .agent-memory/utils.js log-file \
  "app/page.tsx" \
  "edit" \
  "Added Feature component to homepage, lines 15-18"

# When you delete a file
node .agent-memory/utils.js log-file \
  "app/old-component.tsx" \
  "delete" \
  "Removed deprecated component"
```

### Step 5: End Your Session

When you're done:

```bash
node .agent-memory/utils.js end-session \
  "Added new feature component to homepage with responsive design"
```

This will:
- Archive the session to `.agent-memory.json`
- Create a markdown log in `.agent-memory/logs/`
- Clear the current session file
- Update statistics

## Example: Multi-Step Feature Implementation

```bash
# Session starts with first interaction
node .agent-memory/utils.js log-interaction \
  "Implement dark mode toggle" \
  "Starting dark mode implementation"

# Log each file as you work
node .agent-memory/utils.js log-file \
  "app/context/ThemeContext.tsx" \
  "create" \
  "Created theme context with dark/light mode state"

node .agent-memory/utils.js log-file \
  "app/components/ThemeToggle.tsx" \
  "create" \
  "Created toggle button component"

node .agent-memory/utils.js log-file \
  "app/layout.tsx" \
  "edit" \
  "Wrapped app with ThemeProvider, line 12"

node .agent-memory/utils.js log-file \
  "global.css" \
  "edit" \
  "Added dark mode CSS variables and classes"

# Log any issues or decisions
node .agent-memory/utils.js log-interaction \
  "Should we use localStorage or cookies?" \
  "Using localStorage for theme preference persistence"

# End the session
node .agent-memory/utils.js end-session \
  "Implemented complete dark mode with localStorage persistence"
```

## Example: Bug Fix Session

```bash
# Start with the bug report
node .agent-memory/utils.js log-interaction \
  "Navigation menu not working on mobile" \
  "Investigating mobile navigation issue"

# Log investigation steps
node .agent-memory/utils.js log-interaction \
  "Found the issue" \
  "Missing z-index on mobile menu overlay"

# Log the fix
node .agent-memory/utils.js log-file \
  "app/components/Navigation.tsx" \
  "edit" \
  "Fixed mobile menu z-index issue, line 45"

# End session
node .agent-memory/utils.js end-session \
  "Fixed mobile navigation menu z-index bug"
```

## Example: Code Review of Previous Work

```bash
# Review what files were changed in last session
node .agent-memory/utils.js recent-mods 20

# Review a specific session
cat .agent-memory.json | grep -A 50 "session-1760315098769"

# Or read the markdown log
cat .agent-memory/logs/session-1760315098769.md
```

## Integration with Git Workflow

```bash
# Make changes and log them
node .agent-memory/utils.js log-file "src/feature.ts" "create" "New feature"

# End session
node .agent-memory/utils.js end-session "Implemented feature X"

# The memory file is updated, so commit it
git add .agent-memory.json
git commit -m "Implemented feature X (see .agent-memory.json for details)"

# The session log is in .agent-memory/logs/ (gitignored)
# but the summary is in .agent-memory.json (committed)
```

## Bash Helper Script Usage

```bash
# Source the auto-log script for easier access
source .agent-memory/auto-log.sh

# Now you can use shorter commands
show_stats
log_file_mod "path/to/file" "edit" "Description"
end_session "Summary"
```

## Querying Historical Data

### Find all sessions from a specific date
```bash
grep -r "2025-10-13" .agent-memory.json
```

### Find all modifications to a specific file
```bash
grep -A 5 "app/page.tsx" .agent-memory.json
```

### Count total interactions
```bash
grep -c "userInput" .agent-memory.json
```

### List all modified files ever
```bash
grep '"file":' .agent-memory.json | sort -u
```

## Best Practices

1. **Log interactions at key decision points** - Not every tiny step, but important milestones

2. **Be descriptive in file modifications** - Future you will thank you
   - ❌ "edit" 
   - ✅ "Added error handling for API failures"

3. **End sessions with good summaries** - Makes it easy to recall what was done
   - ❌ "made changes"
   - ✅ "Implemented user authentication with JWT tokens and password hashing"

4. **Check previous work before starting** - Avoid duplicate effort
   ```bash
   node .agent-memory/utils.js recent-sessions 5
   ```

5. **Review logs periodically** - Keep the history clean and useful

## Troubleshooting

### Session not logging?
```bash
# Check if current session exists
ls -la .agent-memory/current-session.json

# If it doesn't exist, it will be created on first log
node .agent-memory/utils.js log-interaction "test" "test"
```

### Want to discard current session?
```bash
rm .agent-memory/current-session.json
# Next log will start a new session
```

### Memory file corrupted?
```bash
# Backup first
cp .agent-memory.json .agent-memory.json.backup

# Validate JSON
node -e "console.log(JSON.parse(require('fs').readFileSync('.agent-memory.json')))"
```

### See raw session data
```bash
cat .agent-memory/current-session.json
# or
node -e "console.log(JSON.stringify(require('./.agent-memory/current-session.json'), null, 2))"
```

---

## Summary

The agent memory system is designed to be:
- **Automatic** - Logs are created as you work
- **Persistent** - Survives across sessions via git
- **Queryable** - Easy to search and review
- **Lightweight** - Minimal overhead, pure JSON/markdown
- **Flexible** - Use CLI, scripts, or direct file access

Start each session by reviewing previous work, end each session with a clear summary, and you'll have a complete history of all agent activities in this project!

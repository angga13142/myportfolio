# Agent Memory System

This directory contains the persistent memory system for the AI agent working on this project.

## Files

- `memory.json` - Main memory storage with session history and file modifications
- `utils.js` - Utility functions for logging and memory management
- `current-session.json` - Active session data (cleared on session end)
- `logs/` - Directory containing markdown logs for each session

## Structure

### Sessions
Each session contains:
- `sessionId`: Unique identifier
- `startTime`: Session start timestamp
- `endTime`: Session end timestamp (null if active)
- `interactions`: Array of user inputs and agent responses
- `filesModified`: List of files modified in this session
- `summary`: Brief description of work done

### File Modifications
Each modification contains:
- `file`: File path
- `timestamp`: When the modification occurred
- `sessionId`: Which session made the change
- `changeType`: Type of change (create, edit, delete)
- `description`: Brief description of the change
- `linesAffected`: Array of line numbers or ranges affected

## Usage

The memory system is automatically updated when the agent makes changes to the project.
You can view the memory at any time by checking `.agent-memory.json` or the markdown logs.

### CLI Commands

```bash
# Log an interaction
node .agent-memory/utils.js log-interaction "user message" "agent response"

# Log a file modification
node .agent-memory/utils.js log-file "path/to/file" "edit" "Description of change"

# End current session
node .agent-memory/utils.js end-session "Summary of session work"

# View statistics
node .agent-memory/utils.js stats

# View recent sessions
node .agent-memory/utils.js recent-sessions 5

# View recent modifications
node .agent-memory/utils.js recent-mods 10
```

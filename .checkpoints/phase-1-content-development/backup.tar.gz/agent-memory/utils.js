#!/usr/bin/env node

/**
 * Agent Memory System - Utility Functions
 * Provides functions to log sessions, file modifications, and track changes
 */

const fs = require('fs');
const path = require('path');

const MEMORY_FILE = path.join(__dirname, '..', '.agent-memory.json');
const SESSION_FILE = path.join(__dirname, 'current-session.json');
const LOG_DIR = path.join(__dirname, 'logs');

// Ensure directories exist
if (!fs.existsSync(path.dirname(SESSION_FILE))) {
  fs.mkdirSync(path.dirname(SESSION_FILE), { recursive: true });
}
if (!fs.existsSync(LOG_DIR)) {
  fs.mkdirSync(LOG_DIR, { recursive: true });
}

/**
 * Read memory from JSON file
 */
function readMemory() {
  try {
    if (fs.existsSync(MEMORY_FILE)) {
      return JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf8'));
    }
  } catch (error) {
    console.error('Error reading memory:', error);
  }
  
  return {
    version: "1.0.0",
    projectName: "chronark.com",
    lastUpdated: new Date().toISOString(),
    sessions: [],
    fileModifications: [],
    summary: {
      totalSessions: 0,
      totalModifications: 0,
      lastSessionDate: null
    }
  };
}

/**
 * Write memory to JSON file
 */
function writeMemory(memory) {
  memory.lastUpdated = new Date().toISOString();
  fs.writeFileSync(MEMORY_FILE, JSON.stringify(memory, null, 2));
}

/**
 * Get or create current session
 */
function getCurrentSession() {
  try {
    if (fs.existsSync(SESSION_FILE)) {
      return JSON.parse(fs.readFileSync(SESSION_FILE, 'utf8'));
    }
  } catch (error) {
    console.error('Error reading session:', error);
  }
  
  const session = {
    sessionId: `session-${Date.now()}`,
    startTime: new Date().toISOString(),
    endTime: null,
    interactions: [],
    filesModified: [],
    summary: ""
  };
  
  fs.writeFileSync(SESSION_FILE, JSON.stringify(session, null, 2));
  return session;
}

/**
 * Update current session
 */
function updateSession(session) {
  fs.writeFileSync(SESSION_FILE, JSON.stringify(session, null, 2));
}

/**
 * Log a chat interaction
 */
function logInteraction(userInput, agentResponse) {
  const memory = readMemory();
  const session = getCurrentSession();
  
  const interaction = {
    timestamp: new Date().toISOString(),
    userInput: userInput,
    agentResponse: agentResponse
  };
  
  session.interactions.push(interaction);
  updateSession(session);
  
  console.log(`✓ Logged interaction at ${interaction.timestamp}`);
}

/**
 * Log a file modification
 */
function logFileModification(filePath, changeType, description, linesAffected = []) {
  const memory = readMemory();
  const session = getCurrentSession();
  
  const modification = {
    file: filePath,
    timestamp: new Date().toISOString(),
    sessionId: session.sessionId,
    changeType: changeType, // create, edit, delete, rename
    description: description,
    linesAffected: linesAffected
  };
  
  memory.fileModifications.push(modification);
  memory.summary.totalModifications++;
  
  if (!session.filesModified.includes(filePath)) {
    session.filesModified.push(filePath);
  }
  
  writeMemory(memory);
  updateSession(session);
  
  console.log(`✓ Logged file modification: ${filePath} (${changeType})`);
}

/**
 * End current session and archive it
 */
function endSession(summary = "") {
  const memory = readMemory();
  const session = getCurrentSession();
  
  session.endTime = new Date().toISOString();
  session.summary = summary;
  
  memory.sessions.push(session);
  memory.summary.totalSessions++;
  memory.summary.lastSessionDate = session.endTime;
  
  writeMemory(memory);
  
  // Create session log in markdown
  const logFile = path.join(LOG_DIR, `${session.sessionId}.md`);
  const logContent = generateSessionLog(session);
  fs.writeFileSync(logFile, logContent);
  
  // Clear current session
  if (fs.existsSync(SESSION_FILE)) {
    fs.unlinkSync(SESSION_FILE);
  }
  
  console.log(`✓ Session ended and archived: ${session.sessionId}`);
  console.log(`  Duration: ${getSessionDuration(session)}`);
  console.log(`  Interactions: ${session.interactions.length}`);
  console.log(`  Files Modified: ${session.filesModified.length}`);
}

/**
 * Generate markdown log for a session
 */
function generateSessionLog(session) {
  let md = `# Session Log: ${session.sessionId}\n\n`;
  md += `**Start Time:** ${session.startTime}\n`;
  md += `**End Time:** ${session.endTime || 'In Progress'}\n`;
  md += `**Duration:** ${getSessionDuration(session)}\n\n`;
  
  if (session.summary) {
    md += `## Summary\n\n${session.summary}\n\n`;
  }
  
  md += `## Files Modified (${session.filesModified.length})\n\n`;
  session.filesModified.forEach(file => {
    md += `- ${file}\n`;
  });
  md += `\n`;
  
  md += `## Interactions (${session.interactions.length})\n\n`;
  session.interactions.forEach((interaction, index) => {
    md += `### Interaction ${index + 1}\n`;
    md += `**Time:** ${interaction.timestamp}\n\n`;
    md += `**User:**\n\`\`\`\n${interaction.userInput}\n\`\`\`\n\n`;
    md += `**Agent:**\n\`\`\`\n${interaction.agentResponse}\n\`\`\`\n\n`;
    md += `---\n\n`;
  });
  
  return md;
}

/**
 * Calculate session duration
 */
function getSessionDuration(session) {
  if (!session.endTime) {
    const now = new Date();
    const start = new Date(session.startTime);
    const diff = Math.floor((now - start) / 1000);
    return `${diff}s (ongoing)`;
  }
  
  const start = new Date(session.startTime);
  const end = new Date(session.endTime);
  const diff = Math.floor((end - start) / 1000);
  
  const hours = Math.floor(diff / 3600);
  const minutes = Math.floor((diff % 3600) / 60);
  const seconds = diff % 60;
  
  if (hours > 0) {
    return `${hours}h ${minutes}m ${seconds}s`;
  } else if (minutes > 0) {
    return `${minutes}m ${seconds}s`;
  } else {
    return `${seconds}s`;
  }
}

/**
 * Get recent sessions
 */
function getRecentSessions(count = 5) {
  const memory = readMemory();
  return memory.sessions.slice(-count).reverse();
}

/**
 * Get recent file modifications
 */
function getRecentModifications(count = 10) {
  const memory = readMemory();
  return memory.fileModifications.slice(-count).reverse();
}

/**
 * Search sessions by date range or keyword
 */
function searchSessions(query) {
  const memory = readMemory();
  return memory.sessions.filter(session => {
    const searchText = JSON.stringify(session).toLowerCase();
    return searchText.includes(query.toLowerCase());
  });
}

/**
 * Get statistics
 */
function getStats() {
  const memory = readMemory();
  const currentSession = fs.existsSync(SESSION_FILE) ? getCurrentSession() : null;
  
  return {
    totalSessions: memory.summary.totalSessions,
    totalModifications: memory.summary.totalModifications,
    lastSessionDate: memory.summary.lastSessionDate,
    currentSession: currentSession ? {
      id: currentSession.sessionId,
      startTime: currentSession.startTime,
      interactions: currentSession.interactions.length,
      filesModified: currentSession.filesModified.length
    } : null,
    recentFiles: [...new Set(memory.fileModifications.slice(-20).map(m => m.file))]
  };
}

// CLI Interface
if (require.main === module) {
  const command = process.argv[2];
  
  switch (command) {
    case 'log-interaction':
      logInteraction(process.argv[3] || '', process.argv[4] || '');
      break;
    
    case 'log-file':
      logFileModification(
        process.argv[3],
        process.argv[4] || 'edit',
        process.argv[5] || '',
        process.argv[6] ? JSON.parse(process.argv[6]) : []
      );
      break;
    
    case 'end-session':
      endSession(process.argv[3] || '');
      break;
    
    case 'stats':
      console.log(JSON.stringify(getStats(), null, 2));
      break;
    
    case 'recent-sessions':
      console.log(JSON.stringify(getRecentSessions(parseInt(process.argv[3]) || 5), null, 2));
      break;
    
    case 'recent-mods':
      console.log(JSON.stringify(getRecentModifications(parseInt(process.argv[3]) || 10), null, 2));
      break;
    
    default:
      console.log(`
Agent Memory System - CLI

Commands:
  log-interaction <user> <agent>     Log a chat interaction
  log-file <path> <type> <desc>      Log a file modification
  end-session [summary]              End and archive current session
  stats                              Show memory statistics
  recent-sessions [count]            Show recent sessions
  recent-mods [count]                Show recent modifications
      `);
  }
}

module.exports = {
  logInteraction,
  logFileModification,
  endSession,
  getCurrentSession,
  getRecentSessions,
  getRecentModifications,
  searchSessions,
  getStats
};

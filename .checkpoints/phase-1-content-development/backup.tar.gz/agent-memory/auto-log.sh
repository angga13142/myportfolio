#!/bin/bash

# Auto-logging wrapper script
# This script wraps file operations and automatically logs them to the memory system

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
UTILS="$SCRIPT_DIR/utils.js"

# Function to log file modification
log_file_mod() {
    local file="$1"
    local type="$2"
    local desc="$3"
    node "$UTILS" log-file "$file" "$type" "$desc" 2>/dev/null
}

# Function to log interaction
log_interaction() {
    local user_msg="$1"
    local agent_msg="$2"
    node "$UTILS" log-interaction "$user_msg" "$agent_msg" 2>/dev/null
}

# Function to end session
end_session() {
    local summary="$1"
    node "$UTILS" end-session "$summary"
}

# Function to show stats
show_stats() {
    node "$UTILS" stats
}

# Export functions for use in other scripts
export -f log_file_mod
export -f log_interaction
export -f end_session
export -f show_stats

# If called directly, run the command
if [ "$1" == "stats" ]; then
    show_stats
elif [ "$1" == "end" ]; then
    end_session "$2"
elif [ "$1" == "log" ]; then
    log_file_mod "$2" "$3" "$4"
elif [ "$1" == "interact" ]; then
    log_interaction "$2" "$3"
else
    echo "Agent Memory Auto-Logger"
    echo ""
    echo "Usage:"
    echo "  $0 stats                              Show memory statistics"
    echo "  $0 end [summary]                      End current session"
    echo "  $0 log <file> <type> <description>    Log file modification"
    echo "  $0 interact <user> <agent>            Log interaction"
    echo ""
    echo "Or source this script to use the functions:"
    echo "  source $0"
fi

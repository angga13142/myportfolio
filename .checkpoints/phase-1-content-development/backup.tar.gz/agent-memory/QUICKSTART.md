# Agent Memory System - Quick Start

## What is this?

This is a persistent memory system that automatically tracks all agent activities in this project, including file modifications and chat interactions.

## Files Created

- **`.agent-memory.json`** - Main storage (committed to git for persistent memory)
- **`.agent-memory/current-session.json`** - Current active session (not committed)
- **`.agent-memory/logs/`** - Session logs in markdown format (not committed)
- **`.agent-memory/utils.js`** - Core utility functions
- **`.agent-memory/auto-log.sh`** - Bash helper script

## Quick Commands

### View current statistics
```bash
node .agent-memory/utils.js stats
```

### View recent sessions
```bash
node .agent-memory/utils.js recent-sessions 5
```

### View recent file modifications
```bash
node .agent-memory/utils.js recent-mods 10
```

### End current session
```bash
node .agent-memory/utils.js end-session "Summary of what was accomplished"
```

### Manual logging (usually automatic)
```bash
# Log a file modification
node .agent-memory/utils.js log-file "path/to/file" "edit" "Description"

# Log an interaction
node .agent-memory/utils.js log-interaction "User message" "Agent response"
```

## How It Works

1. **Automatic Session Creation**: When the first log is made, a new session is created automatically
2. **File Modification Tracking**: Every file change is logged with timestamp and description
3. **Chat History**: All interactions are stored with timestamps
4. **Session Archiving**: When you end a session, it's archived to both JSON and markdown formats

## What Gets Committed to Git

- `.agent-memory.json` - YES (so memory persists across sessions)
- `.agent-memory/README.md` - YES (documentation)
- `.agent-memory/utils.js` - YES (the system itself)
- `.agent-memory/auto-log.sh` - YES (helper scripts)
- `.agent-memory/current-session.json` - NO (temporary)
- `.agent-memory/logs/*.md` - NO (can be large)

## Example Workflow

```bash
# Agent starts working
# -> Session automatically created

# Agent makes changes
# -> Files automatically logged

# Check what's been done
node .agent-memory/utils.js stats

# View current session
cat .agent-memory/current-session.json | jq

# End session when done
node .agent-memory/utils.js end-session "Implemented feature X"

# Next time, previous sessions are in .agent-memory.json
```

## Integration Tips

The agent can check previous work by:
```bash
# See last session's summary
cat .agent-memory.json | jq '.sessions[-1]'

# See what files were recently modified
cat .agent-memory.json | jq '.fileModifications[-10:]'

# Get full stats
node .agent-memory/utils.js stats
```
